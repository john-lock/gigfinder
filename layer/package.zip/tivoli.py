import boto3
import os
import json
import requests
from bs4 import BeautifulSoup
from utils import email_dispatch


dynamodb = boto3.resource('dynamodb')


def lambda_handler(event, context):
    table = dynamodb.Table("gigs")
    data = collect()
    for gig in data:
        print('get:')
        print(table.get_item(Key={'id': gig['id'], 'artist': gig['artist'], 'venue': gig['venue'], 'date': gig['date']}))
        print('put:')
        print(table.put_item(Item={'id': gig['id'], 'artist': gig['artist'], 'venue': gig['venue'], 'date': gig['date']}))


def collect():
    print("Collecting Tivoli data")
    base_url = "https://www.tivolivredenburg.nl/wp-admin/admin-ajax.php?action=get_events&categorie=&maand=&page="
    gigs_list = []
    for i in range(50):
        url = base_url + str(i)
        page = requests.get(url)
        if page.text == 'false':
            print('end of gig entries', i)
            break
        else:
            gigs = page.json()
            for gig in gigs:
                day = str(gig['day']).split()[1]
                month = str(gig['yearMonth'][-2:])
                year = str(gig['year'])
                date = f'{year}/{month}/{day}'
                artist = gig['title']
                uid = str(f'{artist}_{venue}')

                new_gig = {'uid': uid,
                           "venue": 'Tivoli',
                           "date": date,
                           "artist": artist,
                           }
                gigs_list.append(new_gig)
    # print(len(gigs_list), 'gigs found for Tivoli')
    return gigs_list
