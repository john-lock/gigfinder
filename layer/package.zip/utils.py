

def email_dispatch(subject, body):
    return requests.post(
        "https://api.mailgun.net/v3/" + MAILGUN_API_DOMAIN + "/messages",
        auth=("api", MAILGUN_API_KEY),
        data={
            "from": "Gig Finder <mailgun@" + MAILGUN_API_DOMAIN + ">",
            "to": NOTIFY_EMAIL_ADDRESS,
            "subject": subject,
            "text": body,
        },
    )